@echo off
cd /d "%~dp0"
echo ======================================================================
echo   Jarvis AI - Standalone Android .APK Builder
echo ======================================================================
echo.
where gradle >nul 2>nul
if %errorlevel% equ 0 (
    echo [1/2] Found Gradle! Compiling app-debug.apk...
    call gradle assembleDebug
    echo.
    echo [SUCCESS] Your APK is ready at:
    echo   app\build\outputs\apk\debug\app-debug.apk
    explorer "app\build\outputs\apk\debug"
    pause
    exit /b
)

if exist "%LOCALAPPDATA%\Android\Sdk" (
    echo Found Android SDK at %LOCALAPPDATA%\Android\Sdk
    echo Please open this folder in Android Studio and click:
    echo   Build -^> Build Bundle(s) / APK(s) -^> Build APK(s)
    pause
    exit /b
)

echo [No Local Android SDK Detected on This PC]
echo You can generate the .APK in 60 seconds without installing Android Studio (3GB):
echo.
echo   OPTION A (Instant Web-to-APK Converter - 60 Seconds):
echo     1. Go to https://www.webintoapp.com/ or https://appsgeyser.com/
echo     2. Upload the file: app\src\main\assets\index.html
echo     3. Click "Make App" to download your installable Jarvis.apk!
echo.
echo   OPTION B (Free GitHub Cloud Builder - Included in this folder):
echo     1. Upload this folder to a free GitHub repository
echo     2. Click the "Actions" tab on GitHub -^> "Build Jarvis Android APK"
echo     3. Download "Jarvis-AI-Android-APK" (app-debug.apk) directly to your phone!
echo.
pause
