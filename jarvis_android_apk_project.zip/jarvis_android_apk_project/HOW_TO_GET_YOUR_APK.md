# How to Get & Install Your Standalone `Jarvis-AI.apk` on Android

Because compiling a binary `.apk` requires the Android SDK compiler (`aapt2` + `d8` + `apksigner`), this package gives you **the complete native Android project (`com.jarvis.ai`)** and **3 zero-hassle ways** to get the `.apk` onto your phone—even if you don't have Android Studio installed.

## Way 1: 60-Second Online APK Compiler (Fastest — Zero Software Install)
Inside this zip, the file **`app/src/main/assets/index.html`** is a 100% self-contained mobile app with embedded manifest, icons, Hindi/English speech, live internet search, and persistent memory.
1. Extract **`jarvis_android_apk_project.zip`** on your computer or phone.
2. Open **[WebIntoApp (Free HTML to APK)](https://www.webintoapp.com/html-to-app)** in your browser.
3. Click **HTML File** -> Upload **`app/src/main/assets/index.html`**.
4. Set App Name to **`Jarvis AI`**, click **Next** -> **Make App (Free)**, and download your **`Jarvis-AI.apk`** file!
5. Send the `.apk` to your Android phone and tap it to install.

## Way 2: Automatic GitHub Cloud APK Compiler (100% Native Java + WebView `.apk`)
This folder includes a full native Android Java project (`MainActivity.java` with native `android.speech.tts.TextToSpeech` Hindi/English bridge and microphone permissions) plus an automated GitHub Actions cloud builder (`.github/workflows/build-apk.yml`):
1. Create a free repository on **[GitHub](https://github.com/new)** and upload the contents of this extracted folder.
2. Click the **Actions** tab at the top of your GitHub repository.
3. GitHub's cloud servers will automatically run **Build Jarvis Android APK** and compile `app-debug.apk` in ~2 minutes.
4. Click on the completed workflow run and download **`Jarvis-AI-Android-APK`** (`app-debug.apk`).

## Way 3: Build Locally on Windows (`build_apk_windows.bat` or Android Studio)
If you have [Android Studio](https://developer.android.com/studio) or Gradle installed on your PC:
1. Open the extracted **`jarvis_android_apk_project`** folder in Android Studio (or double-click **`build_apk_windows.bat`**).
2. In Android Studio, click **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
3. Your installable APK will be saved at:
   `app/build/outputs/apk/debug/app-debug.apk`
