package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private static final int REQ_MIC = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Native Android Hindi & English Text-To-Speech
        tts = new TextToSpeech(this, this);

        // Request Microphone Permission at Runtime on Android 6.0+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            }
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Expose Native Android TTS to JavaScript as window.AndroidNativeTTS
        webView.addJavascriptInterface(new NativeTTSBridge(), "AndroidNativeTTS");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp:") ||
                    url.startsWith("mailto:") || url.startsWith("tel:") ||
                    url.contains("youtube.com")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true;
            tts.setLanguage(new Locale("hi", "IN"));
        }
    }

    public class NativeTTSBridge {
        @JavascriptInterface
        public void speak(String text, String langTag, String pitchStr, String rateStr) {
            if (!ttsReady || tts == null) return;
            try {
                float pitch = Float.parseFloat(pitchStr);
                float rate = Float.parseFloat(rateStr);
                tts.setPitch(pitch);
                tts.setSpeechRate(rate);
                if (langTag != null && langTag.toLowerCase().startsWith("hi")) {
                    tts.setLanguage(new Locale("hi", "IN"));
                } else if (langTag != null && langTag.toLowerCase().contains("gb")) {
                    tts.setLanguage(Locale.UK);
                } else if (langTag != null && langTag.toLowerCase().contains("us")) {
                    tts.setLanguage(Locale.US);
                } else {
                    tts.setLanguage(new Locale("en", "IN"));
                }
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt");
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) {
                tts.stop();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
